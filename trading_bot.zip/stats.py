import json
import os
from datetime import datetime, date
import uuid

DATA_FILE = "trading_data.json"

DEFAULT_PROTECTION = {
    "daily_loss_limit": 20,      # % потерь в день
    "max_daily_trades": 10,      # макс сделок в день
    "loss_streak_limit": 3,      # макс потерь подряд
}


class StatsManager:
    def __init__(self):
        self.data = self._load()

    def _load(self) -> dict:
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {
            "signals": [],
            "protection": DEFAULT_PROTECTION.copy(),
        }

    def _save(self):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    def add_signal(self, signal: dict) -> str:
        signal_id = str(uuid.uuid4())[:8]
        entry = {
            "id": signal_id,
            "pair": signal["pair"],
            "direction": signal["direction"],
            "strength": signal["strength"],
            "price": signal["price"],
            "time": datetime.now().strftime("%H:%M"),
            "date": str(date.today()),
            "result": None,  # win / loss / None
        }
        self.data["signals"].append(entry)
        self._save()
        return signal_id

    def record_result(self, signal_id: str, result: str):
        for s in self.data["signals"]:
            if s["id"] == signal_id:
                s["result"] = result
                break
        self._save()

    def get_today_stats(self) -> dict:
        today = str(date.today())
        today_signals = [s for s in self.data["signals"] if s["date"] == today and s["result"]]
        return self._calc_stats(today_signals)

    def get_stats(self, period: str) -> dict | list:
        if period == "pairs":
            return self._get_pairs_stats()
        
        today = date.today()
        filtered = []
        
        for s in self.data["signals"]:
            if not s["result"]:
                continue
            try:
                signal_date = date.fromisoformat(s["date"])
            except Exception:
                continue
            
            delta = (today - signal_date).days
            if period == "today" and delta == 0:
                filtered.append(s)
            elif period == "week" and delta <= 7:
                filtered.append(s)
            elif period == "month" and delta <= 30:
                filtered.append(s)
        
        return self._calc_stats(filtered)

    def _calc_stats(self, signals: list) -> dict:
        total = len(signals)
        wins = sum(1 for s in signals if s["result"] == "win")
        losses = total - wins
        winrate = round((wins / total * 100), 1) if total > 0 else 0
        
        # Серии
        best_streak = 0
        worst_streak = 0
        current_win = 0
        current_loss = 0
        
        for s in signals:
            if s["result"] == "win":
                current_win += 1
                current_loss = 0
                best_streak = max(best_streak, current_win)
            else:
                current_loss += 1
                current_win = 0
                worst_streak = max(worst_streak, current_loss)
        
        # Текущая серия
        streak = ""
        if signals:
            last = signals[-1]["result"]
            count = 1
            for s in reversed(signals[:-1]):
                if s["result"] == last:
                    count += 1
                else:
                    break
            streak = f"{'🔥' if last == 'win' else '❄️'} {count} {'побед' if last == 'win' else 'потерь'} подряд"
        
        return {
            "total": total,
            "wins": wins,
            "losses": losses,
            "winrate": winrate,
            "best_streak": best_streak,
            "worst_streak": worst_streak,
            "streak": streak or "Нет данных",
        }

    def _get_pairs_stats(self) -> list:
        pairs_data = {}
        for s in self.data["signals"]:
            if not s["result"]:
                continue
            pair = s["pair"]
            if pair not in pairs_data:
                pairs_data[pair] = {"wins": 0, "total": 0}
            pairs_data[pair]["total"] += 1
            if s["result"] == "win":
                pairs_data[pair]["wins"] += 1
        
        result = []
        for pair, data in pairs_data.items():
            if data["total"] > 0:
                result.append({
                    "pair": pair,
                    "total": data["total"],
                    "winrate": round(data["wins"] / data["total"] * 100, 1)
                })
        
        return sorted(result, key=lambda x: x["winrate"], reverse=True)

    def get_history(self, limit: int = 10) -> list:
        with_results = [s for s in self.data["signals"] if s["result"]]
        return list(reversed(with_results[-limit:]))

    def check_protection(self) -> dict:
        today = str(date.today())
        today_signals = [s for s in self.data["signals"] if s["date"] == today and s["result"]]
        
        prot = self.data["protection"]
        trades_today = len(today_signals)
        
        # Серия потерь
        loss_streak = 0
        for s in reversed(today_signals):
            if s["result"] == "loss":
                loss_streak += 1
            else:
                break
        
        # Проверяем лимиты
        if trades_today >= prot["max_daily_trades"]:
            return {
                "blocked": True,
                "reason": f"⛔ Достигнут лимит сделок: {trades_today}/{prot['max_daily_trades']}",
                "trades_today": trades_today,
                "loss_streak": loss_streak,
            }
        
        if loss_streak >= prot["loss_streak_limit"]:
            return {
                "blocked": True,
                "reason": f"⛔ Серия потерь: {loss_streak} подряд. Сделай паузу!",
                "trades_today": trades_today,
                "loss_streak": loss_streak,
            }
        
        return {
            "blocked": False,
            "reason": "",
            "trades_today": trades_today,
            "loss_streak": loss_streak,
        }

    def get_protection_settings(self) -> dict:
        return self.data["protection"]
