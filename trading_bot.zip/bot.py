import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes
)
from datetime import datetime
import json
from signals import SignalEngine
from stats import StatsManager

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ── Загружаем токен из переменной окружения ──────────────────────────────────
TOKEN = os.environ.get("BOT_TOKEN")
OWNER_ID = int(os.environ.get("OWNER_ID", "0"))  # твой Telegram ID

signal_engine = SignalEngine()
stats_manager = StatsManager()

# ════════════════════════════════════════════════════════════════════════════
#  КОМАНДЫ
# ════════════════════════════════════════════════════════════════════════════

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = (
        f"👋 Привет, {user.first_name}!\n\n"
        "🤖 *Торговый бот для бинарных опционов*\n\n"
        "Я анализирую рынок и даю сигналы на основе:\n"
        "• RSI (перекупленность/перепроданность)\n"
        "• MACD (направление тренда)\n"
        "• Bollinger Bands (выход из канала)\n"
        "• Свечные паттерны\n\n"
        "⚠️ *Важно:* Всегда торгуй с умом. Сигналы — это помощь, не гарантия.\n\n"
        "Используй /menu для управления ботом."
    )
    await update.message.reply_text(text, parse_mode='Markdown')


async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [
            InlineKeyboardButton("📊 Получить сигнал", callback_data="get_signal"),
            InlineKeyboardButton("📈 Статистика", callback_data="stats"),
        ],
        [
            InlineKeyboardButton("⚙️ Настройки", callback_data="settings"),
            InlineKeyboardButton("📋 История сделок", callback_data="history"),
        ],
        [
            InlineKeyboardButton("🛡️ Защита депозита", callback_data="protection"),
            InlineKeyboardButton("❓ Помощь", callback_data="help"),
        ],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = "🏠 *Главное меню*\nВыбери действие:"
    
    if update.message:
        await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    else:
        await update.callback_query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')


async def get_signal_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    # Проверяем защиту депозита
    protection = stats_manager.check_protection()
    if protection['blocked']:
        await query.edit_message_text(
            f"🛑 *Торговля заблокирована*\n\n{protection['reason']}\n\n"
            "Защита депозита активна. Возобновится завтра.",
            parse_mode='Markdown'
        )
        return

    await query.edit_message_text("🔍 Анализирую рынок...", parse_mode='Markdown')
    
    # Выбор пары
    keyboard = [
        [
            InlineKeyboardButton("EUR/USD", callback_data="signal_EURUSD"),
            InlineKeyboardButton("GBP/USD", callback_data="signal_GBPUSD"),
        ],
        [
            InlineKeyboardButton("USD/JPY", callback_data="signal_USDJPY"),
            InlineKeyboardButton("AUD/USD", callback_data="signal_AUDUSD"),
        ],
        [
            InlineKeyboardButton("BTC/USD", callback_data="signal_BTCUSD"),
            InlineKeyboardButton("ETH/USD", callback_data="signal_ETHUSD"),
        ],
        [
            InlineKeyboardButton("🔀 Авто (лучшая пара)", callback_data="signal_AUTO"),
        ],
        [InlineKeyboardButton("◀️ Назад", callback_data="main_menu")],
    ]
    await query.edit_message_text(
        "📊 *Выбери пару для анализа:*",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )


async def signal_for_pair(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    pair = query.data.replace("signal_", "")
    
    await query.edit_message_text(f"⏳ Анализирую {'лучшую пару' if pair == 'AUTO' else pair}...")
    
    signal = signal_engine.get_signal(pair)
    
    if signal['direction'] == 'WAIT':
        text = (
            f"⏸ *Нет чёткого сигнала*\n\n"
            f"Пара: `{signal['pair']}`\n"
            f"Рынок сейчас неопределённый. Лучше подождать.\n\n"
            f"🕐 Попробуй через 5-10 минут."
        )
        keyboard = [[InlineKeyboardButton("🔄 Попробовать снова", callback_data="get_signal"),
                     InlineKeyboardButton("🏠 Меню", callback_data="main_menu")]]
    else:
        emoji = "🟢" if signal['direction'] == 'CALL' else "🔴"
        strength_emoji = {"STRONG": "💪", "MEDIUM": "👍", "WEAK": "⚠️"}.get(signal['strength'], "")
        
        text = (
            f"{emoji} *СИГНАЛ: {signal['direction']}*\n\n"
            f"💱 Пара: `{signal['pair']}`\n"
            f"⏱ Экспирация: *{signal['expiry']} мин*\n"
            f"💪 Сила сигнала: {strength_emoji} *{signal['strength']}*\n\n"
            f"📋 *Почему этот сигнал:*\n{signal['reason']}\n\n"
            f"📊 Цена входа: `{signal['price']}`\n"
            f"🕐 Время: {datetime.now().strftime('%H:%M:%S')}\n\n"
            f"⚠️ _Торгуй осознанно. Не более 3-5% депозита на сделку._"
        )
        
        signal_id = stats_manager.add_signal(signal)
        keyboard = [
            [
                InlineKeyboardButton("✅ Выиграл", callback_data=f"result_win_{signal_id}"),
                InlineKeyboardButton("❌ Проиграл", callback_data=f"result_loss_{signal_id}"),
            ],
            [InlineKeyboardButton("🔄 Ещё сигнал", callback_data="get_signal"),
             InlineKeyboardButton("🏠 Меню", callback_data="main_menu")]
        ]
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')


async def result_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    parts = query.data.split("_")
    result = parts[1]  # win or loss
    signal_id = parts[2]
    
    stats_manager.record_result(signal_id, result)
    stats = stats_manager.get_today_stats()
    
    emoji = "🎉" if result == "win" else "😔"
    text = (
        f"{emoji} *Результат записан!*\n\n"
        f"📊 *Статистика сегодня:*\n"
        f"Сделок: {stats['total']}\n"
        f"Побед: {stats['wins']} ✅\n"
        f"Поражений: {stats['losses']} ❌\n"
        f"Винрейт: *{stats['winrate']}%*\n"
        f"Серия: {stats['streak']}"
    )
    keyboard = [
        [InlineKeyboardButton("📊 Ещё сигнал", callback_data="get_signal"),
         InlineKeyboardButton("📈 Полная статистика", callback_data="stats")],
        [InlineKeyboardButton("🏠 Меню", callback_data="main_menu")]
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')


async def stats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [
            InlineKeyboardButton("📅 Сегодня", callback_data="stats_today"),
            InlineKeyboardButton("📆 Неделя", callback_data="stats_week"),
        ],
        [
            InlineKeyboardButton("🗓 Месяц", callback_data="stats_month"),
            InlineKeyboardButton("🏆 Лучшие пары", callback_data="stats_pairs"),
        ],
        [InlineKeyboardButton("◀️ Назад", callback_data="main_menu")],
    ]
    await query.edit_message_text(
        "📈 *Статистика* — выбери период:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )


async def stats_period_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    period = query.data.replace("stats_", "")
    
    stats = stats_manager.get_stats(period)
    
    if period == "pairs":
        text = "🏆 *Лучшие пары по винрейту:*\n\n"
        for i, p in enumerate(stats, 1):
            text += f"{i}. `{p['pair']}` — {p['winrate']}% ({p['total']} сделок)\n"
        if not stats:
            text += "Пока нет данных. Торгуй и отмечай результаты!"
    else:
        period_names = {"today": "Сегодня", "week": "Неделя", "month": "Месяц"}
        text = (
            f"📊 *Статистика — {period_names.get(period, period)}*\n\n"
            f"Всего сделок: *{stats['total']}*\n"
            f"✅ Побед: *{stats['wins']}*\n"
            f"❌ Поражений: *{stats['losses']}*\n"
            f"📈 Винрейт: *{stats['winrate']}%*\n"
            f"🔥 Лучшая серия: *{stats['best_streak']}*\n"
            f"💀 Худшая серия: *{stats['worst_streak']}*\n"
        )
    
    keyboard = [
        [InlineKeyboardButton("◀️ Назад", callback_data="stats"),
         InlineKeyboardButton("🏠 Меню", callback_data="main_menu")]
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')


async def history_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    history = stats_manager.get_history(10)
    
    if not history:
        text = "📋 *История пуста*\n\nНачни торговать и отмечай результаты!"
    else:
        text = "📋 *Последние 10 сделок:*\n\n"
        for h in history:
            emoji = "✅" if h['result'] == 'win' else "❌" if h['result'] == 'loss' else "⏳"
            direction_emoji = "🟢" if h['direction'] == 'CALL' else "🔴"
            text += f"{emoji} {direction_emoji} `{h['pair']}` — {h['time']}\n"
    
    keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="main_menu")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')


async def protection_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    protection = stats_manager.get_protection_settings()
    status = stats_manager.check_protection()
    
    status_text = "🔴 ЗАБЛОКИРОВАНО" if status['blocked'] else "🟢 Активна"
    
    text = (
        f"🛡️ *Защита депозита*\n\n"
        f"Статус: {status_text}\n\n"
        f"⚙️ *Текущие настройки:*\n"
        f"Стоп по убытку в день: *{protection['daily_loss_limit']}%*\n"
        f"Макс. сделок в день: *{protection['max_daily_trades']}*\n"
        f"Стоп при серии потерь: *{protection['loss_streak_limit']}* подряд\n\n"
        f"📊 *Сегодня:*\n"
        f"Сделок: {status['trades_today']}/{protection['max_daily_trades']}\n"
        f"Серия потерь: {status['loss_streak']}/{protection['loss_streak_limit']}"
    )
    keyboard = [
        [InlineKeyboardButton("⚙️ Изменить лимиты", callback_data="protection_edit")],
        [InlineKeyboardButton("◀️ Назад", callback_data="main_menu")]
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')


async def settings_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("⏱ Таймфрейм: 1 мин", callback_data="set_tf_1"),
         InlineKeyboardButton("⏱ Таймфрейм: 5 мин", callback_data="set_tf_5")],
        [InlineKeyboardButton("🔔 Авто-сигналы: ВКЛ", callback_data="toggle_auto"),],
        [InlineKeyboardButton("◀️ Назад", callback_data="main_menu")],
    ]
    await query.edit_message_text(
        "⚙️ *Настройки бота*\n\nВыбери что изменить:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )


async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    text = (
        "❓ *Помощь*\n\n"
        "📊 *Как пользоваться:*\n"
        "1. Нажми «Получить сигнал»\n"
        "2. Выбери пару или «Авто»\n"
        "3. Дождись сигнала\n"
        "4. Войди в сделку на Pocket Option\n"
        "5. Отметь результат (выиграл/проиграл)\n\n"
        "📈 *Индикаторы:*\n"
        "• RSI — показывает перекупленность\n"
        "• MACD — направление тренда\n"
        "• Bollinger Bands — выход из диапазона\n\n"
        "🛡️ *Управление рисками:*\n"
        "• Не ставь более 3-5% депозита\n"
        "• Используй защиту депозита\n"
        "• При 3 потерях подряд — сделай паузу\n\n"
        "⚠️ _Торговля — это риск. Никогда не торгуй на последние деньги._"
    )
    keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="main_menu")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    
    if data == "main_menu":
        await menu(update, context)
    elif data == "get_signal":
        await get_signal_handler(update, context)
    elif data.startswith("signal_"):
        await signal_for_pair(update, context)
    elif data == "stats":
        await stats_handler(update, context)
    elif data.startswith("stats_"):
        await stats_period_handler(update, context)
    elif data == "history":
        await history_handler(update, context)
    elif data == "protection":
        await protection_handler(update, context)
    elif data == "settings":
        await settings_handler(update, context)
    elif data == "help":
        await help_handler(update, context)
    elif data.startswith("result_"):
        await result_handler(update, context)
    else:
        await query.answer("Скоро будет готово! 🔧")


def main():
    if not TOKEN:
        raise ValueError("BOT_TOKEN не задан в переменных окружения!")
    
    app = Application.builder().token(TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", menu))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    logger.info("Бот запущен!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
