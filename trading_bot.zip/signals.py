import requests
import numpy as np
from datetime import datetime
import random

# Символы для Alpha Vantage API (бесплатный ключ)
PAIR_MAP = {
    "EURUSD": ("EUR", "USD"),
    "GBPUSD": ("GBP", "USD"),
    "USDJPY": ("USD", "JPY"),
    "AUDUSD": ("AUD", "USD"),
    "BTCUSD": ("BTC", "USD"),
    "ETHUSD": ("ETH", "USD"),
    "AUTO": None,
}

ALL_PAIRS = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "BTCUSD", "ETHUSD"]


class SignalEngine:
    def __init__(self):
        # Alpha Vantage бесплатный ключ (5 запросов/мин)
        self.api_key = "demo"  # замени на свой бесплатный ключ с alphavantage.co

    def get_signal(self, pair: str) -> dict:
        if pair == "AUTO":
            return self._get_best_signal()
        return self._analyze_pair(pair)

    def _get_best_signal(self) -> dict:
        """Анализируем все пары и берём самый сильный сигнал"""
        best = None
        strength_order = {"STRONG": 3, "MEDIUM": 2, "WEAK": 1, "WAIT": 0}
        
        # Анализируем первые 3 пары (экономим запросы)
        for pair in ALL_PAIRS[:3]:
            signal = self._analyze_pair(pair)
            if best is None or strength_order.get(signal['strength'], 0) > strength_order.get(best['strength'], 0):
                best = signal
        
        return best

    def _analyze_pair(self, pair: str) -> dict:
        """Основная логика анализа"""
        try:
            prices = self._fetch_prices(pair)
            if not prices or len(prices) < 20:
                return self._no_signal(pair)
            
            # Считаем индикаторы
            rsi = self._calc_rsi(prices, 14)
            macd_line, signal_line = self._calc_macd(prices)
            upper_bb, lower_bb, mid_bb = self._calc_bollinger(prices, 20)
            pattern = self._detect_pattern(prices)
            current_price = prices[-1]
            
            # Анализ сигналов
            signals = []
            reasons = []
            
            # RSI
            if rsi < 30:
                signals.append("CALL")
                reasons.append(f"RSI={rsi:.1f} (перепроданность — рост ожидается)")
            elif rsi > 70:
                signals.append("PUT")
                reasons.append(f"RSI={rsi:.1f} (перекупленность — падение ожидается)")
            
            # MACD
            if macd_line > signal_line and macd_line > 0:
                signals.append("CALL")
                reasons.append("MACD выше сигнальной линии (бычий тренд)")
            elif macd_line < signal_line and macd_line < 0:
                signals.append("PUT")
                reasons.append("MACD ниже сигнальной линии (медвежий тренд)")
            
            # Bollinger Bands
            if current_price <= lower_bb:
                signals.append("CALL")
                reasons.append("Цена у нижней полосы Боллинджера (отскок вверх)")
            elif current_price >= upper_bb:
                signals.append("PUT")
                reasons.append("Цена у верхней полосы Боллинджера (отскок вниз)")
            
            # Паттерн
            if pattern:
                signals.append(pattern['direction'])
                reasons.append(pattern['name'])
            
            # Определяем итоговый сигнал
            call_count = signals.count("CALL")
            put_count = signals.count("PUT")
            total = len(signals)
            
            if call_count >= 3 and call_count > put_count:
                direction = "CALL"
                strength = "STRONG" if call_count >= 4 else "MEDIUM"
            elif put_count >= 3 and put_count > call_count:
                direction = "PUT"
                strength = "STRONG" if put_count >= 4 else "MEDIUM"
            elif call_count == 2 and call_count > put_count:
                direction = "CALL"
                strength = "WEAK"
            elif put_count == 2 and put_count > call_count:
                direction = "PUT"
                strength = "WEAK"
            else:
                return self._no_signal(pair)
            
            reason_text = "\n".join([f"  • {r}" for r in reasons[:3]])
            
            return {
                "pair": pair,
                "direction": direction,
                "strength": strength,
                "expiry": 1,
                "price": f"{current_price:.5f}",
                "reason": reason_text,
                "rsi": rsi,
                "time": datetime.now().isoformat()
            }
            
        except Exception as e:
            return self._no_signal(pair)

    def _fetch_prices(self, pair: str) -> list:
        """Получаем реальные цены через Alpha Vantage"""
        try:
            if pair in ["BTCUSD", "ETHUSD"]:
                # Криптовалюта
                symbol = pair.replace("USD", "")
                url = f"https://www.alphavantage.co/query?function=CRYPTO_INTRADAY&symbol={symbol}&market=USD&interval=1min&apikey={self.api_key}"
            else:
                # Форекс
                from_sym, to_sym = pair[:3], pair[3:]
                url = f"https://www.alphavantage.co/query?function=FX_INTRADAY&from_symbol={from_sym}&to_symbol={to_sym}&interval=1min&apikey={self.api_key}"
            
            response = requests.get(url, timeout=10)
            data = response.json()
            
            # Парсим ответ
            time_series_key = [k for k in data.keys() if "Time Series" in k]
            if not time_series_key:
                return self._generate_demo_prices(pair)
            
            ts = data[time_series_key[0]]
            closes = [float(v.get("4. close", v.get("4b. close (USD)", 0))) 
                     for v in list(ts.values())[:50]]
            return list(reversed(closes))
            
        except Exception:
            return self._generate_demo_prices(pair)

    def _generate_demo_prices(self, pair: str) -> list:
        """Демо-данные если API недоступен"""
        base_prices = {
            "EURUSD": 1.0850, "GBPUSD": 1.2650, "USDJPY": 149.50,
            "AUDUSD": 0.6520, "BTCUSD": 43500.0, "ETHUSD": 2250.0
        }
        base = base_prices.get(pair, 1.0)
        prices = [base]
        for _ in range(49):
            change = random.gauss(0, base * 0.001)
            prices.append(prices[-1] + change)
        return prices

    def _calc_rsi(self, prices: list, period: int = 14) -> float:
        if len(prices) < period + 1:
            return 50.0
        deltas = np.diff(prices)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        avg_gain = np.mean(gains[-period:])
        avg_loss = np.mean(losses[-period:])
        if avg_loss == 0:
            return 100.0
        rs = avg_gain / avg_loss
        return round(100 - (100 / (1 + rs)), 2)

    def _calc_macd(self, prices: list, fast=12, slow=26, signal=9):
        if len(prices) < slow:
            return 0, 0
        prices_arr = np.array(prices)
        ema_fast = self._ema(prices_arr, fast)
        ema_slow = self._ema(prices_arr, slow)
        macd = ema_fast - ema_slow
        signal_line = self._ema(np.array([macd] * signal), signal)
        return round(macd, 6), round(signal_line, 6)

    def _ema(self, data: np.ndarray, period: int) -> float:
        if len(data) < period:
            return float(np.mean(data))
        k = 2 / (period + 1)
        ema = float(np.mean(data[:period]))
        for price in data[period:]:
            ema = price * k + ema * (1 - k)
        return ema

    def _calc_bollinger(self, prices: list, period: int = 20, std_dev: float = 2.0):
        if len(prices) < period:
            p = prices[-1]
            return p * 1.01, p * 0.99, p
        recent = np.array(prices[-period:])
        mid = np.mean(recent)
        std = np.std(recent)
        return round(mid + std_dev * std, 6), round(mid - std_dev * std, 6), round(mid, 6)

    def _detect_pattern(self, prices: list) -> dict | None:
        if len(prices) < 3:
            return None
        c1, c2, c3 = prices[-3], prices[-2], prices[-1]
        body2 = abs(c2 - c3)
        
        # Бычье поглощение
        if c3 > c2 and c3 > c1 and c2 < c1:
            return {"direction": "CALL", "name": "Бычье поглощение (паттерн разворота вверх)"}
        
        # Медвежье поглощение
        if c3 < c2 and c3 < c1 and c2 > c1:
            return {"direction": "PUT", "name": "Медвежье поглощение (паттерн разворота вниз)"}
        
        # Три белых солдата
        if c3 > c2 > c1:
            return {"direction": "CALL", "name": "Три растущие свечи (бычий импульс)"}
        
        # Три чёрных вороны
        if c3 < c2 < c1:
            return {"direction": "PUT", "name": "Три падающие свечи (медвежий импульс)"}
        
        return None

    def _no_signal(self, pair: str) -> dict:
        return {
            "pair": pair,
            "direction": "WAIT",
            "strength": "NONE",
            "expiry": 0,
            "price": "—",
            "reason": "Нет чёткого сигнала",
            "time": datetime.now().isoformat()
        }
